package servicio_json;

public class Carrito
{
  String descripcion;
  Integer precio;
  Integer cantidad;
  byte[] foto;
  Integer idA;
  Integer cantidadCarrito;
  Integer idCompra;
}
