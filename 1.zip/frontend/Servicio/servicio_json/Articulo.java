/*
  Carlos Pineda Guerrero, octubre 2023
*/

package servicio_json;

import java.sql.Timestamp;

public class Articulo
{
  String descripcion;
  Integer precio;
  Integer cantidad;
  byte[] foto;
  Integer idA;
}
