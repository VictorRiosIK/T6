package servicio_json;

public class ParamEliminaArticulo {
    Integer idArticulo;
    Integer idCompra;
}
