package servicio_json;

public class ParamInsertaCompraA {
    Integer stock;
    Integer id;
    Integer cantidad;
}
